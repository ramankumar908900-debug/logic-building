#include <stdio.h>
int main(){
    int r;
    if(scanf("%d",&r)==1){
        printf("%.2f\n",3.1415926535*r*r);
    }
    return 0;
}